package tienda_josuegarciasanchez.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import tienda_josuegarciasanchez.domain.Rol;

public interface RolRepository extends JpaRepository<Rol, Long> {
    Optional<Rol> findByNombre(String nombre);
}
