package tienda_josuegarciasanchez.service;

import java.util.List;
import tienda_josuegarciasanchez.domain.Categoria;

public interface CategoriaService {
    List<Categoria> getCategorias();
    Categoria getCategoria(Categoria categoria);
    void save(Categoria categoria);
    void delete(Categoria categoria);
}
