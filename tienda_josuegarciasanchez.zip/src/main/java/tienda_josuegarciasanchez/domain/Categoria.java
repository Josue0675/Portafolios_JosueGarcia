package tienda_josuegarciasanchez.domain;

import jakarta.persistence.*;

@Entity
@Table(name="categoria")
public class Categoria {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    private String descripcion;
    private boolean activo = true;

    public Categoria() {}
    public Categoria(String descripcion, boolean activo){ this.descripcion=descripcion; this.activo=activo; }

    public Long getId(){ return id; }
    public void setId(Long id){ this.id=id; }
    public String getDescripcion(){ return descripcion; }
    public void setDescripcion(String descripcion){ this.descripcion=descripcion; }
    public boolean isActivo(){ return activo; }
    public void setActivo(boolean activo){ this.activo=activo; }
}
