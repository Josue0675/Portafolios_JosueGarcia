package tienda_josuegarciasanchez.service.impl;

import java.util.List;
import org.springframework.stereotype.Service;
import tienda_josuegarciasanchez.domain.Factura;
import tienda_josuegarciasanchez.domain.Usuario;
import tienda_josuegarciasanchez.repository.FacturaRepository;
import tienda_josuegarciasanchez.service.FacturaService;

@Service
public class FacturaServiceImpl implements FacturaService {
    private final FacturaRepository facturaRepository;
    public FacturaServiceImpl(FacturaRepository facturaRepository){ this.facturaRepository = facturaRepository; }

    public Factura save(Factura factura){ return facturaRepository.save(factura); }
    public Factura getFactura(Long id){ return facturaRepository.findById(id).orElse(null); }
    public List<Factura> getFacturasUsuario(Usuario usuario){ return facturaRepository.findByUsuarioOrderByFechaDesc(usuario); }
}
