package tienda_josuegarciasanchez.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tienda_josuegarciasanchez.domain.Ruta;

public interface RutaRepository extends JpaRepository<Ruta, Long> {}
