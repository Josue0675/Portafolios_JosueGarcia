package tienda_josuegarciasanchez.service;

import java.util.List;
import java.util.Optional;
import tienda_josuegarciasanchez.domain.Usuario;

public interface UsuarioService {
    List<Usuario> getUsuarios();
    Usuario getUsuario(Usuario usuario);
    Optional<Usuario> findByUsername(String username);
    void save(Usuario usuario, String rolBase);
    void update(Usuario usuario);
    void delete(Usuario usuario);
    void agregarRol(Long usuarioId, Long rolId);
    void quitarRol(Long usuarioId, Long rolId);
}
