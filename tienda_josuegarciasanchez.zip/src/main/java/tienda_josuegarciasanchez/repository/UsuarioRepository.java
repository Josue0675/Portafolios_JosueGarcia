package tienda_josuegarciasanchez.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import tienda_josuegarciasanchez.domain.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByUsernameAndActivoTrue(String username);
    Optional<Usuario> findByUsername(String username);
}
