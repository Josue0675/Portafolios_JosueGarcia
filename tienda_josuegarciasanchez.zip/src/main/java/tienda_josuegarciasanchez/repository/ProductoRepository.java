package tienda_josuegarciasanchez.repository;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import tienda_josuegarciasanchez.domain.Producto;

public interface ProductoRepository extends JpaRepository<Producto, Long> {
    List<Producto> findByPrecioBetweenOrderByPrecioAsc(BigDecimal precioInf, BigDecimal precioSup);

    @Query("select p from Producto p where p.precio between :precioInf and :precioSup order by p.precio asc")
    List<Producto> consultaJPQL(BigDecimal precioInf, BigDecimal precioSup);

    @Query(value="select * from producto p where p.precio between :precioInf and :precioSup order by p.precio asc", nativeQuery=true)
    List<Producto> consultaSQL(BigDecimal precioInf, BigDecimal precioSup);
}
