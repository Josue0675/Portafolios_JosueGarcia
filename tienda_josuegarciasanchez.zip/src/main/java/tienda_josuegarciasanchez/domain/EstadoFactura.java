package tienda_josuegarciasanchez.domain;

public enum EstadoFactura {
    ACTIVA("Activa"), PAGADA("Pagada"), ANULADA("Anulada");
    private final String valorTexto;
    EstadoFactura(String valorTexto){ this.valorTexto = valorTexto; }
    public String getValorTexto(){ return valorTexto; }
}
