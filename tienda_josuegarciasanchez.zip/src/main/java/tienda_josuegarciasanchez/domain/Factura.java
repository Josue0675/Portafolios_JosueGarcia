package tienda_josuegarciasanchez.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="factura")
public class Factura {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    private LocalDateTime fecha = LocalDateTime.now();

    @Enumerated(EnumType.STRING)
    private EstadoFactura estado = EstadoFactura.PAGADA;

    @ManyToOne
    @JoinColumn(name="usuario_id")
    private Usuario usuario;

    private BigDecimal total = BigDecimal.ZERO;

    @OneToMany(mappedBy="factura", cascade=CascadeType.ALL, orphanRemoval=true)
    private List<Item> items = new ArrayList<>();

    public Long getId(){ return id; }
    public void setId(Long id){ this.id=id; }
    public LocalDateTime getFecha(){ return fecha; }
    public void setFecha(LocalDateTime fecha){ this.fecha=fecha; }
    public EstadoFactura getEstado(){ return estado; }
    public void setEstado(EstadoFactura estado){ this.estado=estado; }
    public Usuario getUsuario(){ return usuario; }
    public void setUsuario(Usuario usuario){ this.usuario=usuario; }
    public BigDecimal getTotal(){ return total; }
    public void setTotal(BigDecimal total){ this.total=total; }
    public List<Item> getItems(){ return items; }
    public void setItems(List<Item> items){ this.items=items; }
}
