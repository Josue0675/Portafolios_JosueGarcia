package tienda_josuegarciasanchez.service.impl;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tienda_josuegarciasanchez.domain.Producto;
import tienda_josuegarciasanchez.repository.ProductoRepository;
import tienda_josuegarciasanchez.service.ProductoService;

@Service
public class ProductoServiceImpl implements ProductoService {
    private final ProductoRepository productoRepository;
    public ProductoServiceImpl(ProductoRepository productoRepository){ this.productoRepository = productoRepository; }

    public List<Producto> getProductos(){ return productoRepository.findAll(); }
    public Producto getProducto(Producto producto){ return productoRepository.findById(producto.getId()).orElse(null); }
    public void save(Producto producto){ productoRepository.save(producto); }
    public void delete(Producto producto){ productoRepository.deleteById(producto.getId()); }

    @Transactional(readOnly = true)
    public List<Producto> consultaDerivada(BigDecimal precioInf, BigDecimal precioSup){
        return productoRepository.findByPrecioBetweenOrderByPrecioAsc(precioInf, precioSup);
    }

    @Transactional(readOnly = true)
    public List<Producto> consultaJPQL(BigDecimal precioInf, BigDecimal precioSup){
        return productoRepository.consultaJPQL(precioInf, precioSup);
    }

    @Transactional(readOnly = true)
    public List<Producto> consultaSQL(BigDecimal precioInf, BigDecimal precioSup){
        return productoRepository.consultaSQL(precioInf, precioSup);
    }
}
