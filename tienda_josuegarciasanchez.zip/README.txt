PROYECTO: tienda_josuegarciasanchez

Use H2 en memoria, así no queda una base vieja guardada.
Usuarios: juan/123, rebeca/123, pedro/123
URL: http://localhost:8080
