package tienda_josuegarciasanchez.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import tienda_josuegarciasanchez.domain.Constante;

public interface ConstanteRepository extends JpaRepository<Constante, Long> {
    Optional<Constante> findByAtributo(String atributo);
}
