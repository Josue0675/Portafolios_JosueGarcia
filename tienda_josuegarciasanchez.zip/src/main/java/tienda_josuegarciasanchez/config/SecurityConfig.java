package tienda_josuegarciasanchez.config;

import java.util.ArrayList;
import java.util.List;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import tienda_josuegarciasanchez.domain.Ruta;
import tienda_josuegarciasanchez.service.RutaService;

@Configuration
@SuppressWarnings("deprecation")
public class SecurityConfig {
    private final RutaService rutaService;

    public SecurityConfig(RutaService rutaService) {
        this.rutaService = rutaService;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return NoOpPasswordEncoder.getInstance();
    }

    private String[] rutasPorAcceso(String acceso) {
        List<String> lista = new ArrayList<>();
        for (Ruta r : rutaService.getRutas()) {
            if (r.getAcceso().equalsIgnoreCase(acceso)) {
                lista.add(r.getPatron());
            }
        }
        return lista.toArray(String[]::new);
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        String[] publicUrls = rutasPorAcceso("PUBLIC");
        String[] adminUrls = rutasPorAcceso("ADMIN");
        String[] adminVendUrls = rutasPorAcceso("ADMIN_VENDEDOR");
        String[] usuarioUrls = rutasPorAcceso("USUARIO");

        http.authorizeHttpRequests(auth -> auth
                .requestMatchers(publicUrls).permitAll()
                .requestMatchers(adminUrls).hasRole("ADMIN")
                .requestMatchers(adminVendUrls).hasAnyRole("ADMIN", "VENDEDOR")
                .requestMatchers(usuarioUrls).hasAnyRole("ADMIN", "VENDEDOR", "USUARIO")
                .anyRequest().authenticated()
        );

        http.formLogin(form -> form
                .loginPage("/login")
                .defaultSuccessUrl("/", true)
                .permitAll()
        );

        http.logout(logout -> logout
                .logoutSuccessUrl("/login?logout")
                .permitAll()
        );

        http.exceptionHandling(ex -> ex.accessDeniedPage("/acceso_denegado"));
        http.csrf(csrf -> csrf.ignoringRequestMatchers("/h2-console/**"));
        http.headers(headers -> headers.frameOptions(frame -> frame.sameOrigin()));
        http.httpBasic(Customizer.withDefaults());
        return http.build();
    }
}
