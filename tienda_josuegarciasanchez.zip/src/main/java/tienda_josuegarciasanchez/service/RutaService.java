package tienda_josuegarciasanchez.service;

import java.util.List;
import tienda_josuegarciasanchez.domain.Ruta;

public interface RutaService {
    List<Ruta> getRutas();
}
