package tienda_josuegarciasanchez.domain;

import jakarta.persistence.*;

@Entity
@Table(name="constante")
public class Constante {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(unique=true)
    private String atributo;
    private String valor;

    public Constante() {}
    public Constante(String atributo, String valor){ this.atributo=atributo; this.valor=valor; }

    public Long getId(){ return id; }
    public void setId(Long id){ this.id=id; }
    public String getAtributo(){ return atributo; }
    public void setAtributo(String atributo){ this.atributo=atributo; }
    public String getValor(){ return valor; }
    public void setValor(String valor){ this.valor=valor; }
}
