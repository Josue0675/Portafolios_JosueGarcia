package tienda_josuegarciasanchez.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tienda_josuegarciasanchez.domain.Categoria;

public interface CategoriaRepository extends JpaRepository<Categoria, Long> {}
