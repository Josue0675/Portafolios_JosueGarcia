package tienda_josuegarciasanchez.domain;

import jakarta.persistence.*;

@Entity
@Table(name="ruta")
public class Ruta {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    private String patron;
    private String acceso;

    public Ruta() {}
    public Ruta(String patron, String acceso){ this.patron=patron; this.acceso=acceso; }

    public Long getId(){ return id; }
    public void setId(Long id){ this.id=id; }
    public String getPatron(){ return patron; }
    public void setPatron(String patron){ this.patron=patron; }
    public String getAcceso(){ return acceso; }
    public void setAcceso(String acceso){ this.acceso=acceso; }
}
