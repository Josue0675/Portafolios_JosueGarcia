insert into categoria(id, descripcion, activo) values
(1,'Laptops', true),
(2,'Accesorios', true),
(3,'Monitores', true);

insert into producto(id, descripcion, precio, existencias, ruta_imagen, activo, categoria_id) values
(1,'Laptop Acer Aspire 5', 420000.00, 8, 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=80', true, 1),
(2,'Monitor Samsung 24', 95000.00, 12, 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=900&q=80', true, 3),
(3,'Teclado mecánico RGB', 35000.00, 15, 'https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?auto=format&fit=crop&w=900&q=80', true, 2),
(4,'Mouse inalámbrico', 18000.00, 20, 'https://images.unsplash.com/photo-1527814050087-3793815479db?auto=format&fit=crop&w=900&q=80', true, 2),
(5,'Laptop Lenovo IdeaPad', 510000.00, 5, 'https://images.unsplash.com/photo-1517336714739-489689fd1ca8?auto=format&fit=crop&w=900&q=80', true, 1);

insert into rol(id, nombre) values
(1, 'ADMIN'),
(2, 'VENDEDOR'),
(3, 'USUARIO');

insert into usuario(id, username, password, nombre_completo, correo, activo) values
(1, 'juan', '123', 'Juan Administrador', 'juan@tienda.com', true),
(2, 'rebeca', '123', 'Rebeca Vendedora', 'rebeca@tienda.com', true),
(3, 'pedro', '123', 'Pedro Cliente', 'pedro@tienda.com', true);

insert into usuario_rol(usuario_id, rol_id) values
(1, 1),
(2, 2),
(3, 3);

insert into constante(id, atributo, valor) values
(1, 'impuesto', '0.13'),
(2, 'correo_sistema', 'sistema@tienda.com'),
(3, 'nombre_tienda', 'Tienda de Josué');

insert into ruta(id, patron, acceso) values
(1, '/', 'PUBLIC'),
(2, '/css/**', 'PUBLIC'),
(3, '/js/**', 'PUBLIC'),
(4, '/h2-console/**', 'PUBLIC'),
(5, '/login', 'PUBLIC'),
(6, '/usuario/registro', 'PUBLIC'),
(7, '/usuario/registrar', 'PUBLIC'),
(8, '/consulta/**', 'PUBLIC'),
(9, '/categoria/**', 'ADMIN_VENDEDOR'),
(10, '/producto/**', 'ADMIN_VENDEDOR'),
(11, '/carrito/**', 'USUARIO'),
(12, '/usuario/**', 'ADMIN'),
(13, '/constante/**', 'ADMIN'),
(14, '/usuario_rol/**', 'ADMIN');
