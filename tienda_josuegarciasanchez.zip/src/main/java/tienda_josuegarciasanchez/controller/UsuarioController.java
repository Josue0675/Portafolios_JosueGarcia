package tienda_josuegarciasanchez.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import tienda_josuegarciasanchez.domain.Usuario;
import tienda_josuegarciasanchez.service.CorreoService;
import tienda_josuegarciasanchez.service.UsuarioService;

@Controller
@RequestMapping("/usuario")
public class UsuarioController {
    private final UsuarioService usuarioService;
    private final CorreoService correoService;

    public UsuarioController(UsuarioService usuarioService, CorreoService correoService) {
        this.usuarioService = usuarioService;
        this.correoService = correoService;
    }

    @GetMapping("/listado")
    public String listado(Model model) {
        model.addAttribute("usuarios", usuarioService.getUsuarios());
        return "usuario/listado";
    }

    @GetMapping("/nuevo")
    public String nuevo(Usuario usuario) { return "usuario/modifica"; }

    @PostMapping("/guardar")
    public String guardar(Usuario usuario, RedirectAttributes redirect) {
        if (usuario.getId() == null) {
            usuarioService.save(usuario, "USUARIO");
            correoService.enviarCorreoBienvenida(usuario.getCorreo(), usuario.getNombreCompleto());
            redirect.addFlashAttribute("exito", "Usuario registrado correctamente");
        } else {
            usuarioService.update(usuario);
            redirect.addFlashAttribute("exito", "Usuario actualizado correctamente");
        }
        return "redirect:/usuario/listado";
    }

    @GetMapping("/modificar/{id}")
    public String modificar(Usuario usuario, Model model) {
        model.addAttribute("usuario", usuarioService.getUsuario(usuario));
        return "usuario/modifica";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(Usuario usuario, RedirectAttributes redirect) {
        usuarioService.delete(usuario);
        redirect.addFlashAttribute("exito", "Usuario eliminado correctamente");
        return "redirect:/usuario/listado";
    }

    @GetMapping("/registro")
    public String registro(Usuario usuario) { return "auth/registro"; }

    @PostMapping("/registrar")
    public String registrar(Usuario usuario, RedirectAttributes redirect) {
        usuarioService.save(usuario, "USUARIO");
        redirect.addFlashAttribute("exito", "Cuenta creada correctamente");
        return "redirect:/login";
    }
}
