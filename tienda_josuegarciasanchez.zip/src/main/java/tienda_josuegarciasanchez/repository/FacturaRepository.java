package tienda_josuegarciasanchez.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import tienda_josuegarciasanchez.domain.Factura;
import tienda_josuegarciasanchez.domain.Usuario;

public interface FacturaRepository extends JpaRepository<Factura, Long> {
    List<Factura> findByUsuarioOrderByFechaDesc(Usuario usuario);
}
