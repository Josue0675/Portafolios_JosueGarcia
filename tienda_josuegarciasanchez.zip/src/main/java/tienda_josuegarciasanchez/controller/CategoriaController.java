package tienda_josuegarciasanchez.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import tienda_josuegarciasanchez.domain.Categoria;
import tienda_josuegarciasanchez.service.CategoriaService;

@Controller
@RequestMapping("/categoria")
public class CategoriaController {
    private final CategoriaService categoriaService;

    public CategoriaController(CategoriaService categoriaService) { this.categoriaService = categoriaService; }

    @GetMapping("/listado")
    public String listado(Model model) {
        model.addAttribute("categorias", categoriaService.getCategorias());
        return "categoria/listado";
    }

    @GetMapping("/nuevo")
    public String nuevo(Categoria categoria) { return "categoria/modifica"; }

    @PostMapping("/guardar")
    public String guardar(Categoria categoria, RedirectAttributes redirect) {
        categoriaService.save(categoria);
        redirect.addFlashAttribute("exito", "Categoría guardada correctamente");
        return "redirect:/categoria/listado";
    }

    @GetMapping("/modificar/{id}")
    public String modificar(Categoria categoria, Model model) {
        model.addAttribute("categoria", categoriaService.getCategoria(categoria));
        return "categoria/modifica";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(Categoria categoria, RedirectAttributes redirect) {
        categoriaService.delete(categoria);
        redirect.addFlashAttribute("exito", "Categoría eliminada correctamente");
        return "redirect:/categoria/listado";
    }
}
