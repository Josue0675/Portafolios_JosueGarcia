package tienda_josuegarciasanchez.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name="producto")
public class Producto {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    private String descripcion;
    private BigDecimal precio;
    private int existencias;
    private String rutaImagen;
    private boolean activo = true;

    @ManyToOne
    @JoinColumn(name="categoria_id")
    private Categoria categoria;

    public Long getId(){ return id; }
    public void setId(Long id){ this.id=id; }
    public String getDescripcion(){ return descripcion; }
    public void setDescripcion(String descripcion){ this.descripcion=descripcion; }
    public BigDecimal getPrecio(){ return precio; }
    public void setPrecio(BigDecimal precio){ this.precio=precio; }
    public int getExistencias(){ return existencias; }
    public void setExistencias(int existencias){ this.existencias=existencias; }
    public String getRutaImagen(){ return rutaImagen; }
    public void setRutaImagen(String rutaImagen){ this.rutaImagen=rutaImagen; }
    public boolean isActivo(){ return activo; }
    public void setActivo(boolean activo){ this.activo=activo; }
    public Categoria getCategoria(){ return categoria; }
    public void setCategoria(Categoria categoria){ this.categoria=categoria; }
}
