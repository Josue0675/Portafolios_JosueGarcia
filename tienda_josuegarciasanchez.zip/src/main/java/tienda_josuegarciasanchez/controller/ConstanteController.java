package tienda_josuegarciasanchez.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import tienda_josuegarciasanchez.domain.Constante;
import tienda_josuegarciasanchez.service.ConstanteService;

@Controller
@RequestMapping("/constante")
public class ConstanteController {
    private final ConstanteService constanteService;

    public ConstanteController(ConstanteService constanteService) { this.constanteService = constanteService; }

    @GetMapping("/listado")
    public String listado(Model model) {
        model.addAttribute("constantes", constanteService.getConstantes());
        return "constante/listado";
    }

    @GetMapping("/nuevo")
    public String nuevo(Constante constante) { return "constante/modifica"; }

    @PostMapping("/guardar")
    public String guardar(Constante constante, RedirectAttributes redirect) {
        constanteService.save(constante);
        redirect.addFlashAttribute("exito", "Constante guardada correctamente");
        return "redirect:/constante/listado";
    }

    @GetMapping("/modificar/{id}")
    public String modificar(Constante constante, Model model) {
        model.addAttribute("constante", constanteService.getConstante(constante));
        return "constante/modifica";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(Constante constante, RedirectAttributes redirect) {
        constanteService.delete(constante);
        redirect.addFlashAttribute("exito", "Constante eliminada correctamente");
        return "redirect:/constante/listado";
    }
}
