package tienda_josuegarciasanchez.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name="item_factura")
public class Item {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    private int cantidad;
    private BigDecimal precio = BigDecimal.ZERO;

    @ManyToOne
    @JoinColumn(name="producto_id")
    private Producto producto;

    @ManyToOne
    @JoinColumn(name="factura_id")
    private Factura factura;

    public Long getId(){ return id; }
    public void setId(Long id){ this.id=id; }
    public int getCantidad(){ return cantidad; }
    public void setCantidad(int cantidad){ this.cantidad=cantidad; }
    public BigDecimal getPrecio(){ return precio; }
    public void setPrecio(BigDecimal precio){ this.precio=precio; }
    public Producto getProducto(){ return producto; }
    public void setProducto(Producto producto){ this.producto=producto; }
    public Factura getFactura(){ return factura; }
    public void setFactura(Factura factura){ this.factura=factura; }

    @Transient
    public BigDecimal getSubtotal(){ return precio.multiply(BigDecimal.valueOf(cantidad)); }
}
