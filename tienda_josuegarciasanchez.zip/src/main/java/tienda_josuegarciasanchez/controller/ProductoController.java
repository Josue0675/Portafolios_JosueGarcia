package tienda_josuegarciasanchez.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import tienda_josuegarciasanchez.domain.Producto;
import tienda_josuegarciasanchez.service.CategoriaService;
import tienda_josuegarciasanchez.service.ProductoService;

@Controller
@RequestMapping("/producto")
public class ProductoController {
    private final ProductoService productoService;
    private final CategoriaService categoriaService;

    public ProductoController(ProductoService productoService, CategoriaService categoriaService) {
        this.productoService = productoService;
        this.categoriaService = categoriaService;
    }

    @GetMapping("/listado")
    public String listado(Model model) {
        model.addAttribute("productos", productoService.getProductos());
        return "producto/listado";
    }

    @GetMapping("/nuevo")
    public String nuevo(Producto producto, Model model) {
        model.addAttribute("categorias", categoriaService.getCategorias());
        return "producto/modifica";
    }

    @PostMapping("/guardar")
    public String guardar(Producto producto, RedirectAttributes redirect) {
        productoService.save(producto);
        redirect.addFlashAttribute("exito", "Producto guardado correctamente");
        return "redirect:/producto/listado";
    }

    @GetMapping("/modificar/{id}")
    public String modificar(Producto producto, Model model) {
        model.addAttribute("producto", productoService.getProducto(producto));
        model.addAttribute("categorias", categoriaService.getCategorias());
        return "producto/modifica";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(Producto producto, RedirectAttributes redirect) {
        productoService.delete(producto);
        redirect.addFlashAttribute("exito", "Producto eliminado correctamente");
        return "redirect:/producto/listado";
    }
}
