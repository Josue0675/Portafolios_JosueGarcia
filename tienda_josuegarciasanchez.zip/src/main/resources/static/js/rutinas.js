function addCart(idProducto) {
    window.location.href = '/carrito/add/' + idProducto;
}
