package tienda_josuegarciasanchez.service.impl;

import java.util.List;
import java.util.Optional;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tienda_josuegarciasanchez.domain.Rol;
import tienda_josuegarciasanchez.domain.Usuario;
import tienda_josuegarciasanchez.repository.RolRepository;
import tienda_josuegarciasanchez.repository.UsuarioRepository;
import tienda_josuegarciasanchez.service.UsuarioService;

@Service
public class UsuarioServiceImpl implements UsuarioService {
    private final UsuarioRepository usuarioRepository;
    private final RolRepository rolRepository;
    private final PasswordEncoder passwordEncoder;

    public UsuarioServiceImpl(UsuarioRepository usuarioRepository, RolRepository rolRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.rolRepository = rolRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public List<Usuario> getUsuarios(){ return usuarioRepository.findAll(); }
    public Usuario getUsuario(Usuario usuario){ return usuarioRepository.findById(usuario.getId()).orElse(null); }
    public Optional<Usuario> findByUsername(String username){ return usuarioRepository.findByUsername(username); }

    @Transactional
    public void save(Usuario usuario, String rolBase){
        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
        Rol rol = rolRepository.findByNombre(rolBase).orElseThrow();
        usuario.getRoles().add(rol);
        usuarioRepository.save(usuario);
    }

    @Transactional
    public void update(Usuario usuario){
        Usuario db = usuarioRepository.findById(usuario.getId()).orElseThrow();
        db.setNombreCompleto(usuario.getNombreCompleto());
        db.setCorreo(usuario.getCorreo());
        db.setUsername(usuario.getUsername());
        db.setActivo(usuario.isActivo());
        if (usuario.getPassword() != null && !usuario.getPassword().isBlank()) {
            db.setPassword(passwordEncoder.encode(usuario.getPassword()));
        }
    }

    public void delete(Usuario usuario){ usuarioRepository.deleteById(usuario.getId()); }

    @Transactional
    public void agregarRol(Long usuarioId, Long rolId){
        Usuario usuario = usuarioRepository.findById(usuarioId).orElseThrow();
        Rol rol = rolRepository.findById(rolId).orElseThrow();
        usuario.getRoles().add(rol);
    }

    @Transactional
    public void quitarRol(Long usuarioId, Long rolId){
        Usuario usuario = usuarioRepository.findById(usuarioId).orElseThrow();
        usuario.getRoles().removeIf(r -> r.getId().equals(rolId));
    }
}
