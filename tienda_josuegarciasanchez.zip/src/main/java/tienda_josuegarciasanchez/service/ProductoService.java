package tienda_josuegarciasanchez.service;

import java.math.BigDecimal;
import java.util.List;
import tienda_josuegarciasanchez.domain.Producto;

public interface ProductoService {
    List<Producto> getProductos();
    Producto getProducto(Producto producto);
    void save(Producto producto);
    void delete(Producto producto);
    List<Producto> consultaDerivada(BigDecimal precioInf, BigDecimal precioSup);
    List<Producto> consultaJPQL(BigDecimal precioInf, BigDecimal precioSup);
    List<Producto> consultaSQL(BigDecimal precioInf, BigDecimal precioSup);
}
