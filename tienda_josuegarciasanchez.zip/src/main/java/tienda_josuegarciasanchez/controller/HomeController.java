package tienda_josuegarciasanchez.controller;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import tienda_josuegarciasanchez.service.CarritoService;
import tienda_josuegarciasanchez.service.ProductoService;

@Controller
public class HomeController {
    private final ProductoService productoService;
    private final CarritoService carritoService;

    public HomeController(ProductoService productoService, CarritoService carritoService) {
        this.productoService = productoService;
        this.carritoService = carritoService;
    }

    @GetMapping("/")
    public String inicio(Model model, Authentication auth) {
        model.addAttribute("productos", productoService.getProductos());
        model.addAttribute("usuarioActual", auth != null ? auth.getName() : null);
        model.addAttribute("carritoCantidad", carritoService.getItems().size());
        return "index/index";
    }

    @GetMapping("/login")
    public String login() { return "auth/login"; }
}
