package tienda_josuegarciasanchez.service.impl;

import org.springframework.stereotype.Service;
import tienda_josuegarciasanchez.service.CorreoService;

@Service
public class CorreoServiceImpl implements CorreoService {
    public void enviarCorreoBienvenida(String destino, String nombre) {
        // Implementación opcional para no bloquear el proyecto
    }
}
