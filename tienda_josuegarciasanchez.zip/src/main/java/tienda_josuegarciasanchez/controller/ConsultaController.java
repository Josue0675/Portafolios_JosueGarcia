package tienda_josuegarciasanchez.controller;

import java.math.BigDecimal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import tienda_josuegarciasanchez.service.ProductoService;

@Controller
@RequestMapping("/consulta")
public class ConsultaController {
    private final ProductoService productoService;

    public ConsultaController(ProductoService productoService) { this.productoService = productoService; }

    @GetMapping("/listado")
    public String listado(Model model) {
        model.addAttribute("productos", productoService.getProductos());
        return "consulta/listado";
    }

    @GetMapping("/derivada")
    public String derivada(@RequestParam BigDecimal precioInf, @RequestParam BigDecimal precioSup, Model model) {
        model.addAttribute("productos", productoService.consultaDerivada(precioInf, precioSup));
        model.addAttribute("tipoConsulta", "Consulta derivada");
        return "consulta/listado";
    }

    @GetMapping("/jpql")
    public String jpql(@RequestParam BigDecimal precioInf, @RequestParam BigDecimal precioSup, Model model) {
        model.addAttribute("productos", productoService.consultaJPQL(precioInf, precioSup));
        model.addAttribute("tipoConsulta", "Consulta JPQL");
        return "consulta/listado";
    }

    @GetMapping("/sql")
    public String sql(@RequestParam BigDecimal precioInf, @RequestParam BigDecimal precioSup, Model model) {
        model.addAttribute("productos", productoService.consultaSQL(precioInf, precioSup));
        model.addAttribute("tipoConsulta", "Consulta SQL");
        return "consulta/listado";
    }
}
