package tienda_josuegarciasanchez.service;

public interface CorreoService {
    void enviarCorreoBienvenida(String destino, String nombre);
}
