package tienda_josuegarciasanchez.service.impl;

import java.util.List;
import org.springframework.stereotype.Service;
import tienda_josuegarciasanchez.domain.Categoria;
import tienda_josuegarciasanchez.repository.CategoriaRepository;
import tienda_josuegarciasanchez.service.CategoriaService;

@Service
public class CategoriaServiceImpl implements CategoriaService {
    private final CategoriaRepository categoriaRepository;
    public CategoriaServiceImpl(CategoriaRepository categoriaRepository){ this.categoriaRepository = categoriaRepository; }

    public List<Categoria> getCategorias(){ return categoriaRepository.findAll(); }
    public Categoria getCategoria(Categoria categoria){ return categoriaRepository.findById(categoria.getId()).orElse(null); }
    public void save(Categoria categoria){ categoriaRepository.save(categoria); }
    public void delete(Categoria categoria){ categoriaRepository.deleteById(categoria.getId()); }
}
