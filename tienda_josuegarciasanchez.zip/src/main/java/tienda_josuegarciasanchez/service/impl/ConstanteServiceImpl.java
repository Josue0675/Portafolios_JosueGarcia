package tienda_josuegarciasanchez.service.impl;

import java.util.List;
import org.springframework.stereotype.Service;
import tienda_josuegarciasanchez.domain.Constante;
import tienda_josuegarciasanchez.repository.ConstanteRepository;
import tienda_josuegarciasanchez.service.ConstanteService;

@Service
public class ConstanteServiceImpl implements ConstanteService {
    private final ConstanteRepository constanteRepository;
    public ConstanteServiceImpl(ConstanteRepository constanteRepository){ this.constanteRepository = constanteRepository; }

    public List<Constante> getConstantes(){ return constanteRepository.findAll(); }
    public Constante getConstante(Constante constante){ return constanteRepository.findById(constante.getId()).orElse(null); }
    public void save(Constante constante){ constanteRepository.save(constante); }
    public void delete(Constante constante){ constanteRepository.deleteById(constante.getId()); }
}
