package tienda_josuegarciasanchez.service.impl;

import java.util.List;
import org.springframework.stereotype.Service;
import tienda_josuegarciasanchez.domain.Ruta;
import tienda_josuegarciasanchez.repository.RutaRepository;
import tienda_josuegarciasanchez.service.RutaService;

@Service
public class RutaServiceImpl implements RutaService {
    private final RutaRepository rutaRepository;
    public RutaServiceImpl(RutaRepository rutaRepository){ this.rutaRepository = rutaRepository; }
    public List<Ruta> getRutas(){ return rutaRepository.findAll(); }
}
