package tienda_josuegarciasanchez.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import tienda_josuegarciasanchez.domain.Usuario;
import tienda_josuegarciasanchez.repository.RolRepository;
import tienda_josuegarciasanchez.service.UsuarioService;

@Controller
@RequestMapping("/usuario_rol")
public class UsuarioRolController {
    private final UsuarioService usuarioService;
    private final RolRepository rolRepository;

    public UsuarioRolController(UsuarioService usuarioService, RolRepository rolRepository) {
        this.usuarioService = usuarioService;
        this.rolRepository = rolRepository;
    }

    @GetMapping("/mantenimiento")
    public String mantenimiento(@RequestParam(required = false) Long usuarioId, Model model) {
        model.addAttribute("usuarios", usuarioService.getUsuarios());
        model.addAttribute("roles", rolRepository.findAll());
        if (usuarioId != null) {
            Usuario usuario = new Usuario();
            usuario.setId(usuarioId);
            model.addAttribute("usuarioSeleccionado", usuarioService.getUsuario(usuario));
        }
        return "usuario_rol/mantenimiento";
    }

    @PostMapping("/agregar")
    public String agregar(@RequestParam Long usuarioId, @RequestParam Long rolId) {
        usuarioService.agregarRol(usuarioId, rolId);
        return "redirect:/usuario_rol/mantenimiento?usuarioId=" + usuarioId;
    }

    @PostMapping("/quitar")
    public String quitar(@RequestParam Long usuarioId, @RequestParam Long rolId) {
        usuarioService.quitarRol(usuarioId, rolId);
        return "redirect:/usuario_rol/mantenimiento?usuarioId=" + usuarioId;
    }
}
