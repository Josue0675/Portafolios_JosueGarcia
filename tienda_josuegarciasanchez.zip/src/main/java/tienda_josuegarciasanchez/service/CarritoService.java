package tienda_josuegarciasanchez.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;
import org.springframework.web.context.WebApplicationContext;
import tienda_josuegarciasanchez.domain.Producto;
import tienda_josuegarciasanchez.domain.Venta;

@Service
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class CarritoService {
    private final List<Venta> items = new ArrayList<>();

    public List<Venta> getItems(){ return items; }

    public void addProducto(Producto producto) {
        for (Venta venta : items) {
            if (venta.getProducto().getId().equals(producto.getId())) {
                venta.setCantidad(venta.getCantidad() + 1);
                return;
            }
        }
        items.add(new Venta(producto, 1));
    }

    public void updateCantidad(Long productoId, int cantidad) {
        items.stream()
            .filter(v -> v.getProducto().getId().equals(productoId))
            .findFirst()
            .ifPresent(v -> v.setCantidad(Math.max(1, cantidad)));
    }

    public void removeProducto(Long productoId) {
        items.removeIf(v -> v.getProducto().getId().equals(productoId));
    }

    public BigDecimal getTotal() {
        return items.stream().map(Venta::getSubtotal).reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public void clear() { items.clear(); }
}
