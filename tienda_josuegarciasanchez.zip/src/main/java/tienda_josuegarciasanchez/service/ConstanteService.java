package tienda_josuegarciasanchez.service;

import java.util.List;
import tienda_josuegarciasanchez.domain.Constante;

public interface ConstanteService {
    List<Constante> getConstantes();
    Constante getConstante(Constante constante);
    void save(Constante constante);
    void delete(Constante constante);
}
