package tienda_josuegarciasanchez.controller;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import tienda_josuegarciasanchez.domain.*;
import tienda_josuegarciasanchez.service.*;

@Controller
@RequestMapping("/carrito")
public class CarritoController {
    private final CarritoService carritoService;
    private final ProductoService productoService;
    private final FacturaService facturaService;
    private final UsuarioService usuarioService;

    public CarritoController(CarritoService carritoService, ProductoService productoService,
                             FacturaService facturaService, UsuarioService usuarioService) {
        this.carritoService = carritoService;
        this.productoService = productoService;
        this.facturaService = facturaService;
        this.usuarioService = usuarioService;
    }

    @GetMapping("/add/{id}")
    public String add(@PathVariable Long id) {
        Producto p = new Producto();
        p.setId(id);
        carritoService.addProducto(productoService.getProducto(p));
        return "redirect:/";
    }

    @GetMapping("/listado")
    public String listado(Model model) {
        model.addAttribute("items", carritoService.getItems());
        model.addAttribute("total", carritoService.getTotal());
        return "carrito/listado";
    }

    @PostMapping("/actualizar")
    public String actualizar(@RequestParam Long productoId, @RequestParam int cantidad) {
        carritoService.updateCantidad(productoId, cantidad);
        return "redirect:/carrito/listado";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        carritoService.removeProducto(id);
        return "redirect:/carrito/listado";
    }

    @GetMapping("/facturar")
    public String facturar(Authentication auth) {
        if (auth == null || carritoService.getItems().isEmpty()) {
            return "redirect:/carrito/listado";
        }
        Usuario usuario = usuarioService.findByUsername(auth.getName()).orElseThrow();
        Factura factura = new Factura();
        factura.setUsuario(usuario);
        factura.setTotal(carritoService.getTotal());

        for (Venta venta : carritoService.getItems()) {
            Item item = new Item();
            item.setFactura(factura);
            item.setProducto(venta.getProducto());
            item.setCantidad(venta.getCantidad());
            item.setPrecio(venta.getProducto().getPrecio());
            factura.getItems().add(item);
        }

        Factura guardada = facturaService.save(factura);
        carritoService.clear();
        return "redirect:/carrito/verFactura/" + guardada.getId();
    }

    @GetMapping("/verFactura/{id}")
    public String verFactura(@PathVariable Long id, Model model) {
        model.addAttribute("factura", facturaService.getFactura(id));
        return "carrito/verFactura";
    }
}
