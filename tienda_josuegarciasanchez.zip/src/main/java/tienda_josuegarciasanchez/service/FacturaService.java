package tienda_josuegarciasanchez.service;

import java.util.List;
import tienda_josuegarciasanchez.domain.Factura;
import tienda_josuegarciasanchez.domain.Usuario;

public interface FacturaService {
    Factura save(Factura factura);
    Factura getFactura(Long id);
    List<Factura> getFacturasUsuario(Usuario usuario);
}
